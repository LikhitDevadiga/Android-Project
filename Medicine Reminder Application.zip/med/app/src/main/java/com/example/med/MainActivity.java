package com.example.med;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final String CHANNEL_ID = "ReminderChannel";
    private static final int NOTIFICATION_ID = 1;

    private EditText editTextMedicineName;
    private Button buttonAddMedicine;
    private ListView listViewMedicine;
    private ArrayList<String> medicineList;
    private ArrayAdapter<String> adapter;
    private Button buttonSetReminder;
    private Calendar reminderDateTime;
    private Handler handler;
    private Runnable timeCheckRunnable;
    private Vibrator vibrator;
    private boolean isReminderActive;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextMedicineName = findViewById(R.id.editTextMedicineName);
        buttonAddMedicine = findViewById(R.id.buttonAddMedicine);
        listViewMedicine = findViewById(R.id.listViewMedicine);
        buttonSetReminder = findViewById(R.id.buttonSetReminder);

        medicineList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, medicineList);
        listViewMedicine.setAdapter(adapter);

        buttonAddMedicine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String medicineName = editTextMedicineName.getText().toString().trim();
                if (!medicineName.isEmpty()) {
                    medicineList.add(medicineName);
                    adapter.notifyDataSetChanged();
                    editTextMedicineName.setText("");
                } else {
                    Toast.makeText(MainActivity.this, "Please enter a medicine name", Toast.LENGTH_SHORT).show();
                }
            }
        });

        buttonSetReminder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDateTimePicker();
            }
        });

        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
        createNotificationChannel();

        handler = new Handler();
        timeCheckRunnable = new Runnable() {
            @RequiresApi(api = Build.VERSION_CODES.O)
            @Override
            public void run() {
                checkReminderTime();
                handler.postDelayed(this, 1000); // Check every second
            }
        };
    }

    private void showDateTimePicker() {
        Calendar currentDate = Calendar.getInstance();
        reminderDateTime = Calendar.getInstance();

        new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                reminderDateTime.set(Calendar.YEAR, year);
                reminderDateTime.set(Calendar.MONTH, monthOfYear);
                reminderDateTime.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                new TimePickerDialog(MainActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        reminderDateTime.set(Calendar.HOUR_OF_DAY, hourOfDay);
                        reminderDateTime.set(Calendar.MINUTE, minute);

                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
                        String reminderDateTimeString = dateFormat.format(reminderDateTime.getTime());

                        Toast.makeText(MainActivity.this, "Reminder set for " + reminderDateTimeString, Toast.LENGTH_SHORT).show();

                        if (!isReminderActive) {
                            startReminder();
                        }
                    }
                }, currentDate.get(Calendar.HOUR_OF_DAY), currentDate.get(Calendar.MINUTE), false).show();
            }
        }, currentDate.get(Calendar.YEAR), currentDate.get(Calendar.MONTH), currentDate.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void startReminder() {
        handler.post(timeCheckRunnable);
        isReminderActive = true;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void checkReminderTime() {
        Calendar currentDateTime = Calendar.getInstance();

        if (reminderDateTime.compareTo(currentDateTime) <= 0) {
            // Reminder time reached
            showNotification();
            playAlert();
            isReminderActive = false; // Stop the reminder after it is triggered
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void playAlert() {
        vibrateDevice();
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void vibrateDevice() {
        if (vibrator != null && vibrator.hasVibrator()) {
            vibrator.vibrate(VibrationEffect.createOneShot(1000, VibrationEffect.DEFAULT_AMPLITUDE));
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence channelName = "Reminder Channel";
            String channelDescription = "Channel for medication reminders";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;

            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, channelName, importance);
            channel.setDescription(channelDescription);

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    private void showNotification() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault());
        String reminderDateTimeString = dateFormat.format(reminderDateTime.getTime());
        String medicineName = editTextMedicineName.getText().toString().trim();

        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, 0);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_m3_chip_close)
                .setContentTitle("Medication Reminder")
                .setContentText("Time to take " + medicineName + " at " + reminderDateTimeString)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        notificationManager.notify(NOTIFICATION_ID, builder.build());
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(timeCheckRunnable);
        if (vibrator != null) {
            vibrator.cancel();
        }
    }
}
